from linkzilla import version

USER_AGENT = 'python-sape/%s http://bitbucket.org/lorien/sape' % version.VERSION
DEFAULT_TIMEOUT = 10
DB_DELIMITER = '||'
